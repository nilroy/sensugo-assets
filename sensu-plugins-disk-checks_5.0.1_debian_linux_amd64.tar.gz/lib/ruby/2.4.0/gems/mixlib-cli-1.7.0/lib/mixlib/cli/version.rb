module Mixlib
  module CLI
    VERSION = "1.7.0"
  end
end
