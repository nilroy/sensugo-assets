module FFI
  VERSION = '1.11.3'
end
