require 'codeclimate-test-reporter'
CodeClimate::TestReporter.start
